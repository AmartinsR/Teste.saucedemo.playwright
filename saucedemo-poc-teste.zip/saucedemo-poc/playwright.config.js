
module.exports = {
  use: {
    headless: true,
    baseURL: 'https://www.saucedemo.com/',
  },
  testDir: './tests',
};
